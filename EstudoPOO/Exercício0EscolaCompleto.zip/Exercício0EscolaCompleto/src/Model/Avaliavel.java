package Model;

public interface Avaliavel {
    // metodo abstrato
    void avaliarDesempenho();

}
